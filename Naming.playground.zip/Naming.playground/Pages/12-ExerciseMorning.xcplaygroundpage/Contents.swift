/*: 
 ## Exercise: Fixing Your Morning
 
 There’s a lot to get done before you leave home in the morning. This exercise will help you optimize your routine.
 
 - callout(Exercise): Create a constant for each activity you do in the morning before leaving home: things like `brushTeeth`, `uploadPhotos`, `chooseClothes`, `shower`, `goJogging`, `finishHomework`, `fixLunch`, and so on. Think about how many minutes each activity usually takes, and assign that value to each constant.
 */
let brushTeeth = 3
// Add more here...
let chooseClothes = 15
let shower = 15
let finishHomewrok = 30
let fixLunch = 45
let skinCareRoutine = 10
let fixBreakfast = 15
//: - callout(Exercise): Add up the constants again, but this time in separate groups: one group for things you have to do and another group for things you like to do.\
//:\
//:If there are things you don’t have to do and don't like to do, make a third group and go ahead and sum that one, too. \
//:\
//:Make a new constant for each group.
let totalGetREadyTime = brushTeeth + chooseClothes + shower + finishHomewrok + fixLunch + skinCareRoutine + fixBreakfast
let haveToDos = brushTeeth + shower + skinCareRoutine + finishHomewrok + fixBreakfast
let likeToDos = chooseClothes + fixLunch
/*:
 See what happens to your total time spent getting ready if you tweak the durations of the different activities. How short of a shower would you have to take in order to have more time to message your friends? Or go for a longer run? How much more time would you need if you decided to spend as long as you wanted doing all the activities you like best?
 
 Change the numbers until you’ve got a design for your ideal morning. What would have to change in order for you to be able to actually spend your morning time this way?
*/
let brushteeth = 3
let choosetlothes = 15 - 15
// picking clothes or outfits from the night before helps to conserve on time in the mornings
let Shower = 15
let finishhomewrok = 30 - 20
// finishing up majority of homework from the night before would help save time in the mornings
let fixlunch = 45 - 15
// making something quick and eay instead of a fully cooked meal helps with saving time
let skincareRoutine = 10
let fixbreakfast = 15 - 5
// making something quick helps conserve on time

let totalTime = brushteeth + choosetlothes + Shower + finishhomewrok + fixlunch + skincareRoutine + fixbreakfast 
//:[Previous](@previous)  |  page 13 of 14  |  [Next: Exercise: Good Names](@next)
